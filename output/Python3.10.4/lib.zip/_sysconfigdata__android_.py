# ANDROID: empty default system configuration
build_time_vars = {}
